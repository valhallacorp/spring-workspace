package com.up.vendas.ModuloVendas.repository;

import org.springframework.data.repository.CrudRepository;

import com.up.vendas.ModuloVendas.dominio.Cliente;

public interface ClienteRepository extends CrudRepository<Cliente, Long>{

	
	
}
