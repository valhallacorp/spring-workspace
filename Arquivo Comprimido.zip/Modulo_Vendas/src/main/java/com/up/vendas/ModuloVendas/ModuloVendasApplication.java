package com.up.vendas.ModuloVendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModuloVendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModuloVendasApplication.class, args);
	}
}
