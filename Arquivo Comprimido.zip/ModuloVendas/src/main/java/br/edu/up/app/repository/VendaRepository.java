package br.edu.up.app.repository;

import org.springframework.data.repository.CrudRepository;

import br.edu.up.app.dominio.Venda;

public interface VendaRepository extends CrudRepository<Venda, Long> {


}
